For detailed and full documentation, visit [My Github Repository](https://github.com/codechamp2006/Calculator)



